# Anycontent Downloader Telegram Bot

A Telegram bot built with `pyTelegramBotAPI`, `yt-dlp`, and Flask. It supports eligible public YouTube videos, Instagram Reels, and Facebook videos.

## Setup

1. Create a bot with Telegram's **@BotFather** and copy its token.
2. Add `BOT_TOKEN` as an environment variable. Never commit the token to Git.
3. Set `OWNER_URL` to the owner's real Telegram contact link.
4. Install dependencies:

   ```bash
   pip install -r requirements.txt
   ```

5. Run:

   ```bash
   python bot.py
   ```

The Flask health endpoints are `/` and `/health`, on the configured `PORT` (defaults to `10000`).

## Render deployment

The included `render.yaml` defines a **worker** for reliable Telegram long polling. A worker does not need a public web server to receive Telegram updates; the Flask thread is included as requested, but it does not guarantee uptime or prevent plan-level sleeping by itself. If you want Render to expose the health endpoint, deploy as a Web Service and configure the service's health check path to `/health`; confirm the plan's current sleep policy.

Add these environment variables in Render:
- `BOT_TOKEN` (required secret)
- `OWNER_URL` (your contact link)
- `TUTORIALS_URL` (optional)

## Notes

- The subscribe button points to `https://youtube.com/@bubiloworld_1m?feature=shared`.
- Videos must be public and accessible to the bot. Instagram/Facebook may restrict downloads or require authentication; this project intentionally does not bypass private access controls.
- Only download content you own or have permission to download, and follow platform terms and copyright law.
- Telegram upload limits and `yt-dlp` format availability can vary. Adjust `MAX_FILE_SIZE_MB` conservatively.
- The required caption is `Downloaded Successfully! Power by: @AnycontentDownloaderbot`.
- Temporary files are removed in a `finally` block after upload or on failure.
