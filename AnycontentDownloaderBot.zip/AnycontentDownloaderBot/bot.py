import os
import re
import threading
import logging
import tempfile
from pathlib import Path
from urllib.parse import urlparse

import telebot
from telebot.types import InlineKeyboardMarkup, InlineKeyboardButton
from flask import Flask, jsonify
from yt_dlp import YoutubeDL

# ---------------- Configuration ----------------
BOT_TOKEN = os.getenv("BOT_TOKEN", "").strip()
BOT_USERNAME = "@AnycontentDownloaderbot"
SUBSCRIBE_URL = "https://youtube.com/@bubiloworld_1m?feature=shared"
TUTORIALS_URL = os.getenv("TUTORIALS_URL", "https://youtube.com/@bubiloworld_1m?feature=shared")
OWNER_URL = os.getenv("OWNER_URL", "https://t.me/")  # Set this to your Telegram username/contact URL.
PORT = int(os.getenv("PORT", "10000"))
MAX_FILE_SIZE_MB = int(os.getenv("MAX_FILE_SIZE_MB", "49"))  # Keep below Telegram Bot API upload limits.

if not BOT_TOKEN:
    raise RuntimeError("BOT_TOKEN is missing. Add it as an environment variable in Render.")

logging.basicConfig(
    level=os.getenv("LOG_LEVEL", "INFO"),
    format="%(asctime)s %(levelname)s %(name)s: %(message)s",
)
log = logging.getLogger("anycontent-downloader")

bot = telebot.TeleBot(BOT_TOKEN, parse_mode="HTML", threaded=True)
app = Flask(__name__)

ALLOWED_HOSTS = {
    "youtube.com", "www.youtube.com", "m.youtube.com", "youtu.be", "music.youtube.com",
    "instagram.com", "www.instagram.com", "m.instagram.com",
    "facebook.com", "www.facebook.com", "m.facebook.com", "fb.watch", "www.fb.watch",
}
FINAL_CAPTION = "Downloaded Successfully! Power by: @AnycontentDownloaderbot"


def make_keyboard():
    keyboard = InlineKeyboardMarkup(row_width=1)
    keyboard.add(InlineKeyboardButton("📢 SUBSCRIBE CHANNEL", url=SUBSCRIBE_URL))
    keyboard.add(InlineKeyboardButton("🎬 ALL TUTORIALS", url=TUTORIALS_URL))
    keyboard.add(InlineKeyboardButton("👨‍💻 CONTACT OWNER", url=OWNER_URL))
    return keyboard


def is_supported_url(text):
    """Accept only direct URLs from supported social/video domains."""
    match = re.search(r"https?://[^\s<>]+", text or "", re.IGNORECASE)
    if not match:
        return None
    url = match.group(0).rstrip(".,!?)]}")
    parsed = urlparse(url)
    host = (parsed.hostname or "").lower()
    if parsed.scheme not in ("http", "https") or host not in ALLOWED_HOSTS:
        return None
    return url


def update_status(chat_id, message_id, text):
    try:
        bot.edit_message_text(text, chat_id, message_id, parse_mode="HTML")
    except Exception as exc:
        # Telegram may reject an edit if the text has not changed.
        log.debug("Status edit skipped: %s", exc)


@app.get("/")
def home():
    return jsonify({"status": "ok", "bot": BOT_USERNAME})


@app.get("/health")
def health():
    return jsonify({"status": "healthy"}), 200


def keep_alive():
    """Start Flask in a daemon thread for Render health checks."""
    thread = threading.Thread(
        target=lambda: app.run(host="0.0.0.0", port=PORT, use_reloader=False),
        daemon=True,
        name="flask-keep-alive",
    )
    thread.start()
    return thread


@bot.message_handler(commands=["start"])
def start(message):
    welcome = (
        "✨ <b>WELCOME TO ANY CONTENT DOWNLOADER</b> ✨\n\n"
        "Your simple video downloader for supported YouTube videos, "
        "Instagram Reels, and Facebook videos.\n\n"
        "📥 <b>How to use</b>\n"
        "1. Copy a link to a public video you are allowed to download.\n"
        "2. Send the link here.\n"
        "3. Wait while the bot processes your video.\n\n"
        "🌟 <b>Fast • Simple • Easy to use</b>\n"
        "Please respect copyright, creator rights, and each platform's terms."
    )
    bot.send_message(message.chat.id, welcome, reply_markup=make_keyboard())


@bot.message_handler(commands=["help"])
def help_command(message):
    bot.reply_to(
        message,
        "Send a supported public YouTube, Instagram Reel, or Facebook video URL. "
        "Private, login-protected, age-restricted, or unavailable videos may not work."
    )


@bot.message_handler(content_types=["text"])
def handle_link(message):
    url = is_supported_url(message.text)
    if not url:
        bot.reply_to(
            message,
            "Please send a valid YouTube, Instagram, or Facebook video link.",
            reply_markup=make_keyboard(),
        )
        return

    status = bot.reply_to(message, "🔎 <b>Analyzing...</b>")
    temp_dir = tempfile.mkdtemp(prefix="anycontent_")
    downloaded_file = None

    try:
        update_status(message.chat.id, status.message_id, "⬇️ <b>Downloading (50%)...</b>")

        def progress_hook(data):
            nonlocal downloaded_file
            if data.get("status") == "finished":
                filename = data.get("filename")
                if filename:
                    downloaded_file = Path(filename)

        ydl_opts = {
            "outtmpl": os.path.join(temp_dir, "%(id)s.%(ext)s"),
            "format": "best[ext=mp4][filesize<={}M]/best[filesize<={}M]/best".format(
                MAX_FILE_SIZE_MB, MAX_FILE_SIZE_MB
            ),
            "noplaylist": True,
            "quiet": True,
            "no_warnings": True,
            "restrictfilenames": True,
            "socket_timeout": 25,
            "retries": 2,
            "fragment_retries": 2,
            "max_filesize": MAX_FILE_SIZE_MB * 1024 * 1024,
            "progress_hooks": [progress_hook],
        }

        with YoutubeDL(ydl_opts) as ydl:
            info = ydl.extract_info(url, download=True)
            # Prepare the final file path, including post-processing/merged outputs.
            prepared = Path(ydl.prepare_filename(info))
            candidates = [prepared]
            candidates.extend(Path(temp_dir).glob("*"))
            video_path = next(
                (p for p in candidates if p.is_file() and p.suffix.lower() in
                 {".mp4", ".mkv", ".webm", ".mov", ".m4v"}),
                None,
            )
            if video_path is None:
                raise RuntimeError("The downloaded video file could not be located.")
            downloaded_file = video_path

        if downloaded_file.stat().st_size > MAX_FILE_SIZE_MB * 1024 * 1024:
            raise RuntimeError(
                f"Video is larger than the configured {MAX_FILE_SIZE_MB} MB upload limit."
            )

        update_status(message.chat.id, status.message_id, "📤 <b>Uploading (100%)...</b>")
        with open(downloaded_file, "rb") as video:
            bot.send_video(
                message.chat.id,
                video,
                caption=FINAL_CAPTION,
                supports_streaming=True,
                reply_to_message_id=message.message_id,
            )
        update_status(message.chat.id, status.message_id, "✅ <b>Done! Video sent successfully.</b>")

    except Exception as exc:
        log.exception("Download failed")
        safe_error = str(exc).replace("<", "").replace(">", "")[:250]
        update_status(
            message.chat.id,
            status.message_id,
            "❌ <b>Could not download this video.</b>\n"
            "It may be private, unsupported, too large, or restricted by the platform.\n\n"
            f"<i>Details: {safe_error}</i>",
        )
    finally:
        # Delete the video and any temporary fragments immediately after upload/failure.
        try:
            if os.path.isdir(temp_dir):
                for path in Path(temp_dir).iterdir():
                    try:
                        if path.is_file():
                            os.remove(path)
                    except OSError:
                        log.warning("Could not remove temporary file: %s", path)
                try:
                    os.rmdir(temp_dir)
                except OSError:
                    log.warning("Could not remove temporary directory: %s", temp_dir)
        except OSError:
            log.warning("Cleanup failed for temp directory: %s", temp_dir)


if __name__ == "__main__":
    keep_alive()
    log.info("Starting polling for %s", BOT_USERNAME)
    bot.infinity_polling(skip_pending=True, timeout=30, long_polling_timeout=30)
